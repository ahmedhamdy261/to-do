import 'package:flutter/material.dart';

Color mintGreen = Color(0xFFDFECDB);
Color primary = Colors.blue;
