package com.example.todoo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
